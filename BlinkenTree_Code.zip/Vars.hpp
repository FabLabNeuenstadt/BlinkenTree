#ifndef VARS_HPP
#define VARS_HPP

int count =0;
long lastMillis = 0;
byte curAnim = 0;

#endif
